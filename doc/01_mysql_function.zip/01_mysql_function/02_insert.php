<?php
/*
天龙八部：
1 连接数据库(选表)  mysql_connect() 
2 判断是否连接成功
3 设置字符集
4 准备SQL语句 查找
5 发送SQL语句    mysql_query — 发送一条 MySQL 查询
6 处理结果集     mysql_fetch_assoc — 从结果集中取得一行作为关联数组
7 释放结果集     mysql_free_result — 释放结果内存
8 关闭数据库连接     mysql_close — 关闭 MySQL 连接 
 */
header("Content-Type:text/html; charset=UTF-8");

// 数据库的配置信息
define("HOST", 'localhost');
define('USER', 'root');
define('PASS', 'root');
define('DB', 'myblog');

$mess = "";

// 第一步 连接数据库，数据表
$res = mysql_connect(HOST, USER, PASS);

if (!$res) {
    // 假设数据库连接失败
    die("数据库连接失败".mysql_error());
}

// 连接数据表
mysql_select_db(DB, $res);

// 第二步 设置字符集
mysql_set_charset("UTF8", $res);

// 使用一个数组变量，来模拟一条插入的数据
$arr = array(
    'title' => "文章标题".mt_rand(0,999),
    'author' => "作者".mt_rand(0,999),
    'description' => "description",
    'content' => 'content',
    'status' => mt_rand(0,1),
    'addtime' => time()
);

// var_dump($arr);

// 第三步 准备SQL语句
$sql = "INSERT INTO news (title, author, description, content, status, addtime) VALUES('".$arr['title']."', '".$arr['author']."', '".$arr['description']."', '".$arr['content']."', ".$arr['status'].", ".$arr['addtime'].")";

// echo $sql;
// die;

// 第四步 发送SQL语句
$query = mysql_query($sql);

// var_dump($result);

// 第五步 处理结果集
if(!$query)
{
    die("插入失败");
} else{
    echo "<script>alert('数据添加成功'); window.location = './01_select.php';</script>";
}

// 第八步 关闭连接
mysql_close($res);



// die;    // 退出
// echo "<pre>";
// var_dump($news);
// echo "<pre>";

?>
