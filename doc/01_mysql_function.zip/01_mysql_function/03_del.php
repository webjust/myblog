<?php
/*
天龙八部：
1 连接数据库(选表)  mysql_connect() 
2 判断是否连接成功
3 设置字符集
4 准备SQL语句 查找
5 发送SQL语句    mysql_query — 发送一条 MySQL 查询
6 处理结果集     mysql_fetch_assoc — 从结果集中取得一行作为关联数组
7 释放结果集     mysql_free_result — 释放结果内存
8 关闭数据库连接     mysql_close — 关闭 MySQL 连接 
 */
header("Content-Type:text/html; charset=UTF-8");

// 数据库的配置信息
define("HOST", 'localhost');
define('USER', 'root');
define('PASS', 'root');
define('DB', 'myblog');

$mess = "";

// 第一步 连接数据库，数据表
$res = mysql_connect(HOST, USER, PASS);

if (!$res) {
    // 假设数据库连接失败
    die("数据库连接失败".mysql_error());
}

// 连接数据表
mysql_select_db(DB, $res);

// 第二步 设置字符集
mysql_set_charset("UTF8", $res);

// 第三步 准备SQL语句
$sql = "SELECT * FROM `news`";

// echo $sql;

// 第四步 发送SQL语句
$query = mysql_query($sql);

// var_dump($result);

// 第五步 处理结果集
// $news = mysql_fetch_assoc($result);
// $news = mysql_fetch_assoc($result);
$news = array();
if($query){
    // 第六步 获取结果集
    while($result = mysql_fetch_assoc($query))
    {
        // 保存结果集
        $news[] = $result;
    }
} else{
    $mess = "未查找到任何数据";
}

// 获取记录的数目
$nums = mysql_num_rows($query);

// 第七步 释放结果集
mysql_free_result($query);

// 第八步 关闭连接
mysql_close($res);



// die;    // 退出
// echo "<pre>";
// var_dump($news);
// echo "<pre>";

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>文章列表</title>
</head>
<body>
<table width="1000" border="1" align="center">
    <tr>
        <th>ID</th>
        <th>TITLE</th>
        <th>AUTHOR</th>
        <th>STATUS</th>
        <th>ADDTIME</th>
        <th>ACTION</th>
    </tr>
    <?php foreach($news as $list): ?>
        <tr>
            <td><?php echo $list['id']; ?></td>
            <td><?php echo $list['title']; ?></td>
            <td><?php echo $list['author']; ?></td>
            <td><?php echo $list['status']; ?></td>
            <td><?php echo date("Y-m-d H:i:s", $list['addtime']) ?></td>
            <td><a href="./03_del_handle.php?id=<?php echo $list['id']; ?>">删除</a></td>
        </tr>
    <?php endforeach; ?>
    <tr>
        <td colspan="6" align="center">共有<?php echo $nums; ?>条记录</td>
    </tr>
</table>
</body>
</html>