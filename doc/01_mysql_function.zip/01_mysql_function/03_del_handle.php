<?php
header("Content-Type:text/html; charset=utf-8");
// 数据库的配置信息
define("HOST", 'localhost');
define('USER', 'root');
define('PASS', 'root');
define('DB', 'myblog');

$mess = "";

// 第一步 连接数据库，数据表
$res = mysql_connect(HOST, USER, PASS);

if (!$res) {
    // 假设数据库连接失败
    die("数据库连接失败".mysql_error());
}

// 连接数据表
mysql_select_db(DB, $res);

// 第二步 设置字符集
mysql_set_charset("UTF8", $res);

// 获取要删除的记录的ID
$id = $_GET['id'];

// var_dump($_GET);

// 第三步 准备SQL语句
$sql = "DELETE FROM news WHERE id = $id";
// echo $sql;

// 第四步 发送SQL语句
$query = mysql_query($sql);

// var_dump($result);

// 第五步 处理结果集
if(!$query)
{
	echo "删除失败";
}
else
{
	echo "<script>alert('删除成功'); window.location = './03_del.php';</script>";
}

// 第八步 关闭连接
mysql_close($res);

?>